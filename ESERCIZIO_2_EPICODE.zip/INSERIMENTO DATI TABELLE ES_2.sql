-- INSERIMENTO DATI TAB PRODOTTI
insert into Prodotti (Id_prodotto,Nome_prodotto,Prezzo)
values
(1,"Tablet",300),
(2,"Mouse",20),
(3,"Tastiera",25),
(4,"Monitor",180),
(5,"HHD",90),
(6,"SSD",200),
(7,"RAM",100),
(8,"Router",0),
(9,"Webcam",45),
(10,"GPU",1250),
(11,"Trackpad",500),
(12,"Techmagazine",5),
(13,"Martech",50);

-- INSERIMENTO DATI TAB CLIENTI
insert into clienti (clienti.Id_cliente,clienti.Nome,clienti.Email)
values 
(1,'Antonio',null),
(2,'Battista','battista@mailmail.it'),
(3,'Maria','maria@posta.it'),
(4,'Franca','franca@lettere.it'),
(5,'Ettore',null),
(6,'Arianna','arianna@posta.it'),
(7,'Piero','piero@lavoro.it');


-- ISNERIMENTO DATI TAB ORDINI
insert into ordini (Id_ordine,Id_prodotto,Id_cliente,Qta)
values
(1,2,1,10),
(2,6,2,2),
(3,5,6,3),
(4,1,5,1),
(5,9,7,1),
(6,4,2,2),
(7,11,3,6),
(8,10,1,2),
(9,3,4,3),
(10,7,4,1),
(11,8,6,1);

