-- CREARE LO SCHEMA PRIMA DI LANCIARE LO SCRIPT

create table if not exists Prodotti (
  Id_prodotto int not null ,
  Nome_prodotto varchar (100) ,
  Prezzo decimal(10,2) ,
  primary key (Id_prodotto)
  );
  
  
  create table if not exists clienti (
    Id_cliente int  not null ,
    Nome varchar (50),
    Email varchar (100),
    primary key (Id_cliente)
    );
    
    
    create table if not exists ordini (
      Id_ordine int not null,
      Id_prodotto int unique not null,
      Id_cliente int,
      Qta int,
      primary key (Id_ordine),
      foreign key (Id_prodotto) references Prodotti (Id_prodotto),
      foreign key (Id_cliente) references clienti (Id_cliente)
      );
      
      
      create table if not exists Dettaglio_ordini (
        Id_spedizione int not null auto_increment,
        Id_ordine int not null,
        Id_prodotto int not null,
        Id_cliente int not null ,
        Prezzo_tot decimal (10,2),
        primary key (Id_spedizione),
        foreign key (Id_ordine) references ordini (Id_ordine),
        foreign key (Id_prodotto) references Prodotti (Id_prodotto),
        foreign key (Id_cliente) references clienti (Id_cliente)
        );