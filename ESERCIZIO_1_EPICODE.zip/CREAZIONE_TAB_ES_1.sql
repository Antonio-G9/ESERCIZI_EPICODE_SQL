-- CREARE LO SCHEMA PRIMA SI ESEGUIRE LO SCRIPT
CREATE TABLE IF NOT EXISTS STORE (
  ID_STORE int not null ,
  INDIRIZZO varchar(255) not null,
  CITTA varchar (255) not null,
	TELEFONO varchar (255) unique,
  PRIMARY KEY (ID_STORE)
  );
  
  CREATE TABLE IF NOT EXISTS IMPIEGATO (
    COD_FISC varchar (16) not null unique ,
    NOME varchar (255) not null ,
    TITOLO_STUDIO varchar (255) not null ,
    RECAPITO varchar (255) not null unique,
    PRIMARY KEY (COD_FISC)
    );
    
    CREATE TABLE IF NOT EXISTS SERVIZIO_IMPIEGATO (
      COD_FISC varchar (16) not null,
			ID_STORE int not null,
      DATA_INIZIO date not null,
      DATA_FINE date not null, 
      CARICA varchar (255) not null,
      FOREIGN KEY (ID_STORE) REFERENCES STORE (ID_STORE),
      PRIMARY KEY (COD_FISC, ID_STORE)
      );
      
      
      CREATE TABLE IF NOT EXISTS VIDEOGIOCO (
      ID_GIOCO varchar (255) not null,
      TITOLO varchar (255) not null , 
      SVILUPPATORE varchar (255) not null , 
      ANNO_DISTRIBUZIONE date not null,
      COSTO decimal not null ,
      GENERE varchar (255) not null,
      REMAKE varchar (255) ,
      PRIMARY KEY (ID_GIOCO)
      );
      
      CREATE TABLE IF NOT EXISTS POSIZIONE_GIOCHI (
        ID_POSIZIONE INT AUTO_INCREMENT ,
        ID_GIOCO varchar (255) not null,
        ID_STORE int not null,
        QTA int not null ,
        PRIMARY KEY (ID_POSIZIONE),
        FOREIGN KEY (ID_GIOCO) REFERENCES VIDEOGIOCO(ID_GIOCO),
        FOREIGN KEY (ID_STORE) REFERENCES STORE(ID_STORE)
        );
     