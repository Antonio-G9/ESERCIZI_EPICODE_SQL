-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: epicode_es_1
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `videogioco`
--

DROP TABLE IF EXISTS `videogioco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `videogioco` (
  `ID_GIOCO` varchar(255) NOT NULL,
  `TITOLO` varchar(255) NOT NULL,
  `SVILUPPATORE` varchar(255) NOT NULL,
  `ANNO_DISTRIBUZIONE` date NOT NULL,
  `COSTO` decimal(10,0) NOT NULL,
  `GENERE` varchar(255) NOT NULL,
  `REMAKE` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID_GIOCO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videogioco`
--

LOCK TABLES `videogioco` WRITE;
/*!40000 ALTER TABLE `videogioco` DISABLE KEYS */;
INSERT INTO `videogioco` VALUES ('vid_1','Fifa 2023','EA Sports','2023-01-01',50,'Calcio',NULL),('vid_10','Red Dead Redemption 2','Rockstar Games','2018-01-01',40,'Action-Adventure',NULL),('vid_2','Assassin\'s Creed: Valhalla','Ubisoft','2020-01-01',60,'Action',NULL),('vid_3','Super Mario Odyssey','Nintendo','2017-01-01',40,'Platform',NULL),('vid_4','The Last of Us Part II','Naughty Dog','2020-01-01',70,'Action',NULL),('vid_5','Cyberpunk 2077','CD Projekt Red','2020-01-01',50,'RPG',NULL),('vid_6','Animal Crossing: New Horizons','Nintendo','2020-01-01',55,'Simulation',NULL),('vid_7','Call of Duty: Warzone','Infinity Ward','2020-01-01',0,'FPS',NULL),('vid_8','The Legend of Zelda: Breath of the Wild','Nintendo','2017-01-01',60,'Action-Adventure',NULL),('vid_9','Fortnite','Epic Games','2017-01-01',0,'Battle Royale',NULL);
/*!40000 ALTER TABLE `videogioco` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-11 14:06:47
